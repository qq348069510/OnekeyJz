DROP TABLE IF EXISTS `jianzhan_admin`;
CREATE TABLE `jianzhan_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` char(32) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*!40000 ALTER TABLE `jianzhan_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `jianzhan_admin` ENABLE KEYS */;

DROP TABLE IF EXISTS `jianzhan_config`;
CREATE TABLE `jianzhan_config` (
  `k` varchar(255) NOT NULL DEFAULT '',
  `v` text,
  PRIMARY KEY (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `jianzhan_config` DISABLE KEYS */;
INSERT INTO `jianzhan_config` VALUES ('alipay','1'),('build','1'),('description','鑫迪建站系统-新一代智能自助建站系统,自动化建设神器。易学易懂,功能强大,拥有多种精美网站款式。无需建站技术，一键自动搭建。价格低，性比价高，节省资金！'),('domaingg','您可绑定的默认域名有：aj369.cn<br>绑定自己的域名需要将域名CNAME解析到af369.cn\t\t<a href=\"http://fqa.78vu.cn/628093\" target=\"_blank\">查看帮助</a>'),('epayapi',''),('epayid',''),('epaykey',''),('gg','<li class=\"list-group-item\"><span class=\"badge badge-danger btn-xs\">最新通知</span>  无</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-danger btn-xs\">1</span>  公告1</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-success btn-xs\">2</span>  公告2</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-info btn-xs\">3</span>  公告3</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-warning btn-xs\">4</span>  公告4</li>'),('keywords','鑫迪建站系统,一键建站系统,自助建站,智能建站,建站系统,一键搭建,玩客建站系统,玩客建站,辽宁微时光科技有限公司'),('qqpay','1'),('rechargegg','<li class=\"list-group-item\"><span class=\"badge badge-danger btn-xs\">最新通知</span>  充不起就别注册，穷鬼</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-danger btn-xs\">1</span>  同意一楼说法</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-success btn-xs\">2</span>  同意一楼说法</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-info btn-xs\">3</span>  同意一楼说法</li>\r\n<li class=\"list-group-item\"><span class=\"badge badge-warning btn-xs\">4</span>  同意一楼说法</li>'),('title','鑫迪建站'),('titles','您的首选平台'),('wxpay','1');
/*!40000 ALTER TABLE `jianzhan_config` ENABLE KEYS */;

DROP TABLE IF EXISTS `jianzhan_log`;
CREATE TABLE `jianzhan_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `addres` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `jianzhan_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `jianzhan_log` ENABLE KEYS */;

DROP TABLE IF EXISTS `jianzhan_program`;
CREATE TABLE `jianzhan_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) DEFAULT NULL,
  `name` text,
  `price` float(16,2) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `jianzhan_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `jianzhan_program` ENABLE KEYS */;

DROP TABLE IF EXISTS `jianzhan_recharge`;
CREATE TABLE `jianzhan_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(255) DEFAULT NULL,
  `user` int(11) DEFAULT NULL,
  `money` float(16,2) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `jianzhan_recharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `jianzhan_recharge` ENABLE KEYS */;

DROP TABLE IF EXISTS `jianzhan_site`;
CREATE TABLE `jianzhan_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `optdomain` text,
  `date` datetime DEFAULT NULL,
  `program` int(11) DEFAULT NULL,
  `price` float(16,2) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `jianzhan_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `jianzhan_site` ENABLE KEYS */;

DROP TABLE IF EXISTS `jianzhan_user`;
CREATE TABLE `jianzhan_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` char(32) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT '',
  `balance` float(16,2) DEFAULT '0.00',
  `regdate` datetime DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*!40000 ALTER TABLE `jianzhan_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `jianzhan_user` ENABLE KEYS */;