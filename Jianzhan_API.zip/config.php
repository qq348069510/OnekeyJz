<?php
/*数据库信息配置*/
$database=array(
	'host'=>'localhost', //数据库服务器
	'port'=>'3306', //数据库端口
	'user'=>'root', //数据库用户名
	'pwd'=>'root', //数据库密码
	'dbname'=>'root', //数据库名
	'prefix'=>'jianzhan' //数据表前缀
);
define('LOGIN_KEY', '123');
define('ADMIN_KEY', '456');
?>